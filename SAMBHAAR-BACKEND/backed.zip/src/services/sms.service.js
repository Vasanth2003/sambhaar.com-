// import axios from "axios";

 async function sendSMS(phone, message) {
  console.log(`📨 SMS to ${phone}: ${message}`);

  // OPTIONAL: send to webhook.site or mockbin
  /*
  await axios.post("https://webhook.site/YOUR_ID", {
    phone,
    message,
  });
  */

  return true;
}


// const axios =require("axios") ;

//  async function sendSMS(phone, message) {
//   const url = "https://www.fast2sms.com/dev/bulkV2";

//   await axios.post(
//     url,
//     {
//       route: "q",
//       numbers: phone.replace("+91", ""),
//       message: message,
//     },
//     {
//       headers: {
//         authorization: process.env.FAST2SMS_API_KEY,
//         "Content-Type": "application/json",
//       },
//     }
//   );

  

//   return true;
// }

module.exports = {sendSMS};
